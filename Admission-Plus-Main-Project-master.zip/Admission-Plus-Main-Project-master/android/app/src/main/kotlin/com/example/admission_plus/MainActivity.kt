package com.example.admission_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
