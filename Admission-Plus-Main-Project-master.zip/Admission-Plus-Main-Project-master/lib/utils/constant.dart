class Constant{
  static String uri='https://admission-plus-server.onrender.com';
}
//http://10.0.2.2:3000 for emulator
//http://192.168.237.65:3000 for device