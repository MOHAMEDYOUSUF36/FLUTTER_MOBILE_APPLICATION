//username="mohnish694"
//password="Aishuma5"

const MONGO_CONN_URL=
"mongodb+srv://mohnish694:Aishuma5@cluster0.8tpmc9w.mongodb.net/AdmissionPlus?retryWrites=true&w=majority";
const USER_COLLECTION="MainProject";